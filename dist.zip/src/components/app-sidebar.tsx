import { ComponentProps, memo, useEffect, useState } from "react";
import { ChevronDown } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  SidebarRail,
  useSidebar,
} from "@/components/ui/sidebar";
import { Separator } from "@/components/ui/separator";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { sidebarOptions } from "@/assets/data/sidebarOptions";
import { Link, useLocation } from "react-router-dom";
import BULB_ICON from "../assets/images/bulb.svg";
import COLLAPSABLE_ICON from "../assets/images/collapsable.svg";
import "./style.css";

const AppSidebar = ({ ...props }: ComponentProps<typeof Sidebar>) => {
  const [activeOption, setActiveOption] = useState("/");
  const [openDropdown, setOpenDropdown] = useState<null | string>(null);
  const [isHovered, setIsHovered] = useState("");

  const {
    setOpen,
    toggleMouseEvent,
    isHoverOpen,
    toggleSidebar,
    open,
    setIsOnlyHoverOpen,
  } = useSidebar();
  const { pathname } = useLocation();

  useEffect(() => {
    setActiveOption(pathname);
    const mainOption = sidebarOptions.find((option) =>
      pathname.includes(option.path)
    );
    if (mainOption) {
      setOpenDropdown(mainOption.label);
    }
    return () => {
      setActiveOption("/");
    };
  }, []);

  return (
    <Sidebar
      {...props}
      onMouseLeave={() => {
        if (isHoverOpen) {
          setOpen(false);
          toggleMouseEvent(false);
        }
      }}
      className="flex flex-col justify-between sm:content-between"
    >
      <SidebarContent>
        <SidebarGroup>
          <SidebarMenu className="p-4 sm:p-2 pt-0">
            {sidebarOptions.map(({ label, path, Icon, children }) => (
              <Collapsible
                key={label}
                asChild
                open={children ? label === openDropdown : undefined}
                className="group/collapsible"
              >
                <SidebarMenuItem>
                  <CollapsibleTrigger asChild>
                    <SidebarMenuButton
                      asChild
                      className={`py-6 font-normal text-black cursor-pointer transition-all duration-300 ${
                        activeOption === path
                          ? "bg-[var(--sidebar-selected-option-bg)] text-white hover:bg-[var(--sidebar-selected-option-bg)]"
                          : !children
                          ? "hover:bg-[var(--hover-bg-option)] hover:text-white !important"
                          : ""
                      }`}
                      onClick={() => {
                        if (children?.length) {
                          if (label !== openDropdown) {
                            setOpenDropdown(label);
                          } else {
                            setOpenDropdown(null);
                          }
                        } else {
                          setActiveOption(path);
                        }
                      }}
                    >
                      {children ? (
                        <div className="font-normal text-base flex items-center">
                          {Icon && <Icon />}
                          <span>{label}</span>
                          <ChevronDown
                            className={`ml-auto transition-transform duration-200 ${
                              openDropdown === label ? "rotate-180" : "rotate-0"
                            }`}
                          />
                        </div>
                      ) : (
                        <Link
                          to={path}
                          className="font-normal text-base flex items-center hover:text-black"
                          onMouseEnter={() =>
                            activeOption !== path && setIsHovered(label)
                          }
                          onMouseLeave={() => setIsHovered("")}
                        >
                          {Icon && (
                            <Icon
                              className={`transition-colors duration-100 ${
                                isHovered === label
                                  ? activeOption === path
                                    ? "text-white"
                                    : "text-black"
                                  : ""
                              } `}
                            />
                          )}
                          <span>{label}</span>
                        </Link>
                      )}
                    </SidebarMenuButton>
                  </CollapsibleTrigger>
                  {children && openDropdown === label ? (
                    <CollapsibleContent>
                      <SidebarMenuSub>
                        {children.map((child) => (
                          <SidebarMenuSubItem key={child.label}>
                            <SidebarMenuSubButton
                              asChild
                              className={`pl-5 cursor-pointer py-5 transition-all duration-300  ${
                                activeOption === path + child.path
                                  ? "bg-[var(--sidebar-selected-option-bg)] text-white hover:bg-[var(--sidebar-selected-option-bg)] hover:text-white"
                                  : "text-[var(--light-text)] hover:text-[var(--light-text)] hover:bg-[var(--hover-bg-option)]"
                              } font-normal text-sm`}
                              onClick={() =>
                                setActiveOption(`${path}${child.path}`)
                              }
                            >
                              <Link to={`${child.path}`}>{child.label}</Link>
                            </SidebarMenuSubButton>
                          </SidebarMenuSubItem>
                        ))}
                      </SidebarMenuSub>
                    </CollapsibleContent>
                  ) : null}
                </SidebarMenuItem>
              </Collapsible>
            ))}
          </SidebarMenu>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className={"relative"}>
        <img
          src={COLLAPSABLE_ICON}
          width="40px"
          height="40px"
          className={`absolute right-[-15px] top-[-7px] z-30 cursor-pointer transition-transform duration-200 ${
            open ? "rotate-0" : "rotate-180"
          }`}
          onClick={() => {
            setIsOnlyHoverOpen(open);
            toggleSidebar();
            toggleMouseEvent(false);
          }}
        />
        <Separator className="" />
        <SidebarMenuButton asChild>
          <Link to="/help" className="font-medium">
            <span className="sm:hidden">{""}</span>
            <img src={BULB_ICON} width="20px" height="20px" />
            <span className="font-medium">Help</span>
          </Link>
        </SidebarMenuButton>
      </SidebarFooter>
      <SidebarRail
        onMouseEnter={() => {
          if (!isHoverOpen) {
            setOpen(true);
            toggleMouseEvent(true);
          }
        }}
      />
    </Sidebar>
  );
};

export default memo(AppSidebar);
