import PermissionsTable from "@/components/PermissionsTable";
import { Check } from "lucide-react";
import { Link } from "react-router-dom";

const Permissions = () => {
  return (
    <div className="bg-white w-full rounded-sm max-h-[calc(100svh-var(--navbar-height)-100px)] flex overflow-hidden shadow">
      {/* Left Table Sections */}
      <div
        className={`leftTable h-max max-h-[92%] w-full overflow-hidden overflow-x-auto pb-3`}
      >
        <div className="bg-white h-full w-full rounded-lg ">
          <div className="h-[56px] flex">
            {/* Search Section */}
            <div className="w-[70%] sm:w-1/2 flex items-center pl-4">
              {/* <div className="flex items-center justify-evenly w-[170px] h-[32px] border-2 rounded-lg">
          <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
            <path
              fillRule="evenodd"
              clipRule="evenodd"
              d="M4.70768 1.33317C2.77469 1.33317 1.20768 2.90017 1.20768 4.83317C1.20768 6.76617 2.77469 8.33317 4.70768 8.33317C6.64068 8.33317 8.20768 6.76617 8.20768 4.83317C8.20768 2.90017 6.64068 1.33317 4.70768 1.33317ZM0.0410156 4.83317C0.0410156 2.25584 2.13035 0.166504 4.70768 0.166504C7.28501 0.166504 9.37435 2.25584 9.37435 4.83317C9.37435 5.91159 9.00855 6.90456 8.39427 7.6948L11.5368 10.8374C11.7646 11.0652 11.7646 11.4345 11.5368 11.6623C11.309 11.8901 10.9397 11.8901 10.7119 11.6623L7.56931 8.51975C6.77908 9.13404 5.7861 9.49984 4.70768 9.49984C2.13035 9.49984 0.0410156 7.4105 0.0410156 4.83317Z"
              fill="#7F7D8F"
            />
          </svg>
          <input
            type="search"
            placeholder="Search"
            className={`w-[80%] pl-1 outline-none text-xs ${styles.searchPlaceholder}`}
          />
        </div> */}
              <Link
                to={"/"}
                className="text-[#666666] font-normal text-xl border-b-[1px] border-[#666666]"
              >
                New Role
              </Link>
            </div>
            <div className="w-[30%] sm:w-1/2 flex items-center justify-end pr-4 cursor-pointer ">
              {/* View Setting Button */}
              {/* <span
          className="bg-blue-500"
          onClick={() =>
            setViewSettingMode && setViewSettingMode(!viewSettingMode)
          }
        >
          <svg
            width="13"
            height="12"
            viewBox="0 0 13 12"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              fillRule="evenodd"
              clipRule="evenodd"
              d="M2.12549 0C2.49368 0 2.79216 0.298477 2.79216 0.666667V6.78047C3.56895 7.05503 4.12549 7.79585 4.12549 8.66667C4.12549 9.53748 3.56895 10.2783 2.79216 10.5529V11.3333C2.79216 11.7015 2.49368 12 2.12549 12C1.7573 12 1.45882 11.7015 1.45882 11.3333V10.5529C0.682027 10.2783 0.125488 9.53748 0.125488 8.66667C0.125488 7.79585 0.682027 7.05503 1.45882 6.78047V0.666667C1.45882 0.298477 1.7573 0 2.12549 0ZM6.12549 0C6.49368 0 6.79216 0.298477 6.79216 0.666667V1.44714C7.56895 1.72169 8.12549 2.46252 8.12549 3.33333C8.12549 4.20415 7.56895 4.94497 6.79216 5.21953V11.3333C6.79216 11.7015 6.49368 12 6.12549 12C5.7573 12 5.45882 11.7015 5.45882 11.3333V5.21953C4.68203 4.94497 4.12549 4.20415 4.12549 3.33333C4.12549 2.46252 4.68203 1.72169 5.45882 1.44714V0.666667C5.45882 0.298477 5.7573 0 6.12549 0ZM10.1255 0C10.4937 0 10.7922 0.298477 10.7922 0.666667V6.78047C11.5689 7.05503 12.1255 7.79585 12.1255 8.66667C12.1255 9.53748 11.5689 10.2783 10.7922 10.5529V11.3333C10.7922 11.7015 10.4937 12 10.1255 12C9.7573 12 9.45882 11.7015 9.45882 11.3333V10.5529C8.68203 10.2783 8.12549 9.53748 8.12549 8.66667C8.12549 7.79585 8.68203 7.05503 9.45882 6.78047V0.666667C9.45882 0.298477 9.7573 0 10.1255 0ZM6.12549 2.66667C5.7573 2.66667 5.45882 2.96514 5.45882 3.33333C5.45882 3.70152 5.7573 4 6.12549 4C6.49368 4 6.79216 3.70152 6.79216 3.33333C6.79216 2.96514 6.49368 2.66667 6.12549 2.66667ZM2.12549 8C1.7573 8 1.45882 8.29848 1.45882 8.66667C1.45882 9.03486 1.7573 9.33333 2.12549 9.33333C2.49368 9.33333 2.79216 9.03486 2.79216 8.66667C2.79216 8.29848 2.49368 8 2.12549 8ZM10.1255 8C9.7573 8 9.45882 8.29848 9.45882 8.66667C9.45882 9.03486 9.7573 9.33333 10.1255 9.33333C10.4937 9.33333 10.7922 9.03486 10.7922 8.66667C10.7922 8.29848 10.4937 8 10.1255 8Z"
              fill="#5D54C9"
            />
          </svg>
        </span> */}

              {/* Select All Button */}
              <div className=" flex justify-center items-center gap-4 sm:gap-5">
                <span className="w-[75px] sm:w-[83px] flex items-center gap-1">
                  <label className="inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      // disabled={!perms?.[type.toLowerCase() as keyof typeof perms]}
                      //   defaultChecked={
                      //     !!perms?.[type.toLowerCase() as keyof typeof perms]
                      //   }
                      className="hidden peer"
                    />
                    <div className="w-5 h-5 flex items-center border-2 border-gray-300 rounded bg-white peer-checked:bg-[#5159B8] peer-checked:border-[#5159B8] relative">
                      <Check
                        className="absolute inset-0 m-auto text-white peer-checked:block peer-checked:text-white"
                        size={16}
                      />
                    </div>
                  </label>
                  <label
                    htmlFor="selectAll"
                    className="text-xs sm:text-sm font-medium text-[#999999]"
                  >
                    Select All
                  </label>
                </span>
                <span>
                  <svg width="13" height="12" viewBox="0 0 13 12" fill="none">
                    <path
                      fillRule="evenodd"
                      clipRule="evenodd"
                      d="M0.792216 0C1.16041 0 1.45888 0.298477 1.45888 0.666667V2.22866C2.55847 0.86964 4.24001 0 6.12555 0C9.18577 0 11.71 2.29042 12.0792 5.25084C12.1247 5.6162 11.8655 5.94932 11.5001 5.99488C11.1348 6.04044 10.8016 5.78119 10.7561 5.41583C10.4691 3.11449 8.50482 1.33333 6.12555 1.33333C4.54043 1.33333 3.13887 2.12378 2.29517 3.33333H4.12555C4.49374 3.33333 4.79222 3.63181 4.79222 4C4.79222 4.36819 4.49374 4.66667 4.12555 4.66667H0.792216C0.424026 4.66667 0.125549 4.36819 0.125549 4V0.666667C0.125549 0.298477 0.424026 0 0.792216 0ZM0.750985 6.00512C1.11635 5.95956 1.44946 6.21881 1.49502 6.58417C1.78199 8.88551 3.74628 10.6667 6.12555 10.6667C7.71067 10.6667 9.11223 9.87622 9.95593 8.66667H8.12555C7.75736 8.66667 7.45888 8.36819 7.45888 8C7.45888 7.63181 7.75736 7.33333 8.12555 7.33333H11.4589C11.8271 7.33333 12.1255 7.63181 12.1255 8V11.3333C12.1255 11.7015 11.8271 12 11.4589 12C11.0907 12 10.7922 11.7015 10.7922 11.3333V9.77134C9.69263 11.1304 8.01109 12 6.12555 12C3.06533 12 0.541094 9.70958 0.171935 6.74916C0.126376 6.3838 0.385625 6.05068 0.750985 6.00512Z"
                      fill="#999999"
                    />
                  </svg>
                </span>
              </div>
            </div>
          </div>
          <div className="w-full overflow-x-auto">
            <PermissionsTable />
          </div>
        </div>
      </div>
      {/* View Setting Pannel or Sections */}
      {/* <div
            className={`viewSettings hidden h-[90%] sm:flex items-center justify-center  bg-blue-300 ${
              viewSettingMode ? "w-[30%]" : "hidden"
            }`}
          >
            <div className="w-[90%] h-[90%] bg-white rounded-lg border-[1px]">
              View Settings
            </div>
          </div> */}
    </div>
  );
};

export default Permissions;
